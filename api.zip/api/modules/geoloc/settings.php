<?php

# Where do you want the databases to be located? Use trailing slash
$config['geoloc']['dbLocation'] = dirname(__FILE__) . "/";

